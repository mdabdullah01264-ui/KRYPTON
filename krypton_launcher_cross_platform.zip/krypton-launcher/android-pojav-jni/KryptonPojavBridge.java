package net.krypton.pojavbridge;

import java.io.File;
import java.util.Map;

/**
 * KryptonPojavBridge — Android JNI & PojavLauncher Directory Bridge
 * Compatible with /storage/emulated/0/games/PojavLauncher/.minecraft
 * Supports Vulkan 1.3, Turnip/Zink, MobileGlues, LTW, and HolyGL4ES.
 */
public class KryptonPojavBridge {
    static {
        try {
            System.loadLibrary("pojavexec");
        } catch (UnsatisfiedLinkError ignored) {
            // Loaded dynamically from selected runtime directory on Android
        }
    }

    public static File getPojavMinecraftDir() {
        return new File("/storage/emulated/0/games/PojavLauncher/.minecraft");
    }

    public static File getInstanceDir(String instanceName) {
        File dir = new File(getPojavMinecraftDir(), "instances/" + instanceName);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static native int chdir(String path);
    public static native void setenv(String key, String value, boolean overwrite);
    public static native int launchJvm(String[] jvmArgs);
}
