#!/usr/bin/env python3
"""
Krypton Launcher — Cross-Platform Core Engine (Windows, Linux, Android/Pojav)
Supports:
- PojavLauncher-identical directory layout (.minecraft/instances, runtimes, controlmap, custom_env.txt)
- All Minecraft versions (Classic, Alpha, Beta, Releases 1.0 - 1.21.10+, Snapshots)
- Hardware Renderers: Vulkan 1.3 (VulkanMod), Krypton Zink (GL 4.6 over Vulkan),
  MobileGlues (GL 4.0 over GLES 3.2), LTW (LightThinWrapper), HolyGL4ES (gl4es 1.1.5)
- Modrinth v2 API Mod & Modpack Search and Installer
- Multi-JRE Manager (Java 8, Java 17, Java 21, Java 23)
"""

import json
import os
import platform
import subprocess
import sys
import urllib.request
from pathlib import Path

RENDERER_ENV_MAP = {
    "vulkan_native": {
        "POJAV_RENDERER": "vulkan_mod",
        "LWJGL_VULKAN_LIBNAME": "vulkan-1.dll" if platform.system() == "Windows" else "libvulkan.so.1",
    },
    "vulkan_zink": {
        "POJAV_RENDERER": "vulkan_zink",
        "MESA_LOADER_DRIVER_OVERRIDE": "zink",
        "MESA_GL_VERSION_OVERRIDE": "4.6",
        "MESA_GLSL_VERSION_OVERRIDE": "460",
    },
    "mobileglues": {
        "POJAV_RENDERER": "opengles3_mg",
        "LIBGL_ES": "3",
        "MG_MAX_GLSL_CACHE_SIZE": "64",
    },
    "ltw_gles3": {
        "POJAV_RENDERER": "opengles3_ltw",
        "LIBGL_ES": "3",
    },
    "holy_gl4es": {
        "POJAV_RENDERER": "opengles2",
        "LIBGL_ES": "2",
        "LIBGL_MIPMAP": "3",
    },
}

def get_pojav_minecraft_root() -> Path:
    """Returns the PojavLauncher-compatible .minecraft root directory for Windows, Linux, or Android."""
    if "ANDROID_ROOT" in os.environ or os.path.exists("/storage/emulated/0"):
        return Path("/storage/emulated/0/games/PojavLauncher/.minecraft")
    system = platform.system()
    if system == "Windows":
        appdata = os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        return Path(appdata) / "KryptonLauncher" / "PojavLauncher" / ".minecraft"
    return Path.home() / ".local" / "share" / "krypton" / "PojavLauncher" / ".minecraft"

def ensure_pojav_directory_tree(root: Path, instance_name: str = "Krypton-1.21.10") -> Path:
    """Creates the exact PojavLauncher directory layout."""
    subdirs = [
        root / "assets",
        root / "libraries",
        root / "versions",
        root / "runtimes" / "Internal-JRE-8",
        root / "runtimes" / "Internal-JRE-17",
        root / "runtimes" / "Internal-JRE-21",
        root / "controlmap",
        root / "instances" / instance_name / "mods",
        root / "instances" / instance_name / "shaderpacks",
        root / "instances" / instance_name / "resourcepacks",
        root / "instances" / instance_name / "saves",
        root / "instances" / instance_name / "config",
    ]
    for d in subdirs:
        d.mkdir(parents=True, exist_ok=True)

    custom_env = root / "custom_env.txt"
    if not custom_env.exists():
        custom_env.write_text("POJAV_RENDERER=vulkan_zink\nMESA_GL_VERSION_OVERRIDE=4.6\n", encoding="utf-8")

    override_args = root / "overrideargs.txt"
    if not override_args.exists():
        override_args.write_text("-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=130\n", encoding="utf-8")

    return root / "instances" / instance_name

def select_java_runtime(mc_version: str, root: Path) -> str:
    """Selects JRE 8, JRE 17, or JRE 21 based on the target Minecraft version."""
    if mc_version.startswith(("1.20.5", "1.20.6", "1.21", "24w", "25w")):
        jre_folder = "Internal-JRE-21"
    elif mc_version.startswith(("1.17", "1.18", "1.19", "1.20")):
        jre_folder = "Internal-JRE-17"
    else:
        jre_folder = "Internal-JRE-8"
    candidate = root / "runtimes" / jre_folder / "bin" / ("java.exe" if platform.system() == "Windows" else "java")
    return str(candidate) if candidate.exists() else "java"

def search_modrinth(query: str, project_type: str = "mod", limit: int = 10) -> list:
    """Queries Modrinth v2 API for mods, modpacks, shaders, or resourcepacks."""
    facets = json.dumps([[f"project_type:{project_type}"]])
    url = f"https://api.modrinth.com/v2/search?query={urllib.parse.quote(query)}&facets={urllib.parse.quote(facets)}&limit={limit}"
    req = urllib.request.Request(url, headers={"User-Agent": "KryptonLauncher/2.0.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data.get("hits", [])

def build_launch_command(
    username: str = "ImranMd",
    version: str = "1.21.10",
    instance_name: str = "Krypton-1.21.10",
    renderer: str = "vulkan_native",
    ram_mb: int = 4096,
) -> tuple[list[str], dict[str, str]]:
    root = get_pojav_minecraft_root()
    instance_dir = ensure_pojav_directory_tree(root, instance_name)
    java_bin = select_java_runtime(version, root)

    env = os.environ.copy()
    env.update(RENDERER_ENV_MAP.get(renderer, RENDERER_ENV_MAP["vulkan_native"]))

    cmd = [
        java_bin,
        f"-Xms1024M",
        f"-Xmx{ram_mb}M",
        "-XX:+UseG1GC",
        "-XX:+ParallelRefProcEnabled",
        "-XX:MaxGCPauseMillis=130",
        f"-Djava.library.path={root / 'natives'}",
        "-Dminecraft.launcher.brand=Krypton-Launcher",
        "-cp",
        f"{root / 'libraries' / '*'}{os.pathsep}{root / 'versions' / version / (version + '.jar')}",
        "net.minecraft.client.main.Main",
        "--username", username,
        "--version", version,
        "--gameDir", str(instance_dir),
        "--assetsDir", str(root / "assets"),
        "--accessToken", "0",
    ]
    return cmd, env

if __name__ == "__main__":
    cmd, env_vars = build_launch_command()
    print("[Krypton Launcher] Pojav-Compatible Root:", get_pojav_minecraft_root())
    print("[Krypton Launcher] Generated Command:\n ", " ".join(cmd))
