#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::process::Command;

#[tauri::command]
fn launch_minecraft(
    username: String,
    version: String,
    instance_folder: String,
    renderer: String,
    ram_mb: u32,
) -> Result<String, String> {
    let output = Command::new("python3")
        .arg("../core/krypton_core.py")
        .env("KRYPTON_USER", &username)
        .env("KRYPTON_VERSION", &version)
        .env("KRYPTON_INSTANCE", &instance_folder)
        .env("POJAV_RENDERER", &renderer)
        .env("KRYPTON_RAM_MB", ram_mb.to_string())
        .output()
        .map_err(|e| e.to_string())?;

    Ok(String::from_utf8_lossy(&output.stdout).to_string())
}

fn main() {
    println!("Krypton Launcher Tauri Bridge Initialized (Windows / Linux / Android)");
}
