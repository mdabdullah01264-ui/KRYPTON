# Krypton Launcher (v2.0.0) — Cross-Platform Vulkan & Pojav Minecraft Launcher

**Krypton Launcher** is a cross-platform Minecraft launcher for **Windows**, **Linux**, and **Android** featuring the dark cosmic purple UI, multi-renderer pipeline (**Vulkan 1.3 / VulkanMod**, **Krypton Zink**, **MobileGlues**, **LTW**, **HolyGL4ES**), **Modrinth / CurseForge Mod & Modpack Manager**, **Multi-Java Runtime (JRE 8 / 17 / 21 / 23)**, and a **100% PojavLauncher-compatible `.minecraft` instance directory structure**.

## Directory Structure (PojavLauncher Compatible)

All three operating systems share the exact same `.minecraft` layout so you can transfer instances, worlds, mods, and shaders directly between PC and Android:

- **Android**: `/storage/emulated/0/games/PojavLauncher/.minecraft/`
- **Windows**: `%APPDATA%\KryptonLauncher\PojavLauncher\.minecraft\`
- **Linux**: `~/.local/share/krypton/PojavLauncher/.minecraft/`

Inside `.minecraft/`:
- `instances/<InstanceName>/` (`mods/`, `shaderpacks/`, `resourcepacks/`, `saves/`, `config/`, `options.txt`)
- `runtimes/` (`Internal-JRE-8`, `Internal-JRE-17`, `Internal-JRE-21`)
- `controlmap/` (Android touch & gyroscope mappings)
- `custom_env.txt` & `overrideargs.txt`

## Quick Start

1. **Interactive UI (`ui/index.html`)**: Open directly in any modern browser, Tauri WebView, or Electron container.
2. **Python Core Engine (`core/krypton_core.py`)**:
   ```bash
   python3 core/krypton_core.py
   ```
3. **Desktop & Android Native Packaging (`src-tauri/` & `android-pojav-jni/`)**:
   - Windows / Linux: `cargo tauri build`
   - Android APK: `cargo tauri android build` (links `KryptonPojavBridge.java` and `libpojavexec.so`)
